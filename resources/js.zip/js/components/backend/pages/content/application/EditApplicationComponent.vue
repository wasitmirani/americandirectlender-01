<template>
    <div>
       <FormWizard></FormWizard>
    </div>
</template>
<script>
import FormWizard from "./components/FormWizard.vue";
export default {
  components:{
      FormWizard
    },
}


</script>

<template>
  <div>
    <div class=row>
        <div class="col-xl-4 col-sm-6">
        <div class="card browser-widget">
          <div class="media card-body">
            <div class="media-img">
              <img src="/assets/images/dashboard/chrome.png" alt="" />
            </div>
            <div class="media-body align-self-center">
              <div>
                <p>Daily</p>
                <h4><span class="counter">20</span>%</h4>
              </div>
              <div>
                <p>Month</p>
                <h4><span class="counter">53</span>%</h4>
              </div>
              <div>
                <p>Week</p>
                <h4><span class="counter">25</span>%</h4>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-xl-4 col-sm-6">
        <div class="card browser-widget">
          <div class="media card-body">
            <div class="media-img">
              <img src="assets/images/dashboard/firefox.png" alt="" />
            </div>
            <div class="media-body align-self-center">
              <div>
                <p>Daily</p>
                <h4><span class="counter">20</span>%</h4>
              </div>
              <div>
                <p>Month</p>
                <h4><span class="counter">53</span>%</h4>
              </div>
              <div>
                <p>Week</p>
                <h4><span class="counter">25</span>%</h4>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="col-xl-4 col-sm-6">
        <div class="card browser-widget">
          <div class="media card-body">
            <div class="media-img">
              <img src="/assets/images/dashboard/safari.png" alt="" />
            </div>
            <div class="media-body align-self-center">
              <div>
                <p>Daily</p>
                <h4><span class="counter">19</span>%</h4>
              </div>
              <div>
                <p>Month</p>
                <h4><span class="counter">52</span>%</h4>
              </div>
              <div>
                <p>Week</p>
                <h4><span class="counter">25</span>%</h4>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
export default{

}
</script>
